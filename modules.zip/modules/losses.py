import numpy as np


class BaseLoss:

    def func(self, X, y, w):
        raise NotImplementedError('Func oracle is not implemented.')

    def grad(self, X, y, w):
        raise NotImplementedError('Grad oracle is not implemented.')


class LinearLoss(BaseLoss):
    l2_coef = 0.0

    def __init__(self, l2_coef):
        self.l2_coef = l2_coef

    def func(self, X, y, w):
        N = X.shape[0]
        left = X.dot(w) - y
        loss = np.mean((left) ** 2)
        w_reg = w.copy()
        reg_term = self.l2_coef * np.sum(w[1:] ** 2)
        return loss + reg_term

    def grad(self, X, y, w):
        N = X.shape[0]
        r = X.dot(w) - y
        grad = (2.0 / N) * (X.T.dot(r))
        reg = 2.0 * self.l2_coef * w
        reg = reg.copy()
        reg[0] = 0.0

        return grad + reg

