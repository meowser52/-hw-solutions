import numpy as np
import time
import pandas as pd
import scipy.sparse



class LinearModel:
    def __init__(
        self,
        loss_function,
        batch_size=None,
        step_alpha=1,
        step_beta=0,
        tolerance=1e-5,
        max_iter=1000,
        random_seed=153,
        **kwargs
    ):
        self.loss_function = loss_function
        self.batch_size = batch_size
        self.step_alpha = float(step_alpha)
        self.step_beta = float(step_beta)
        self.tolerance = float(tolerance)
        self.max_iter = int(max_iter)
        self.random_seed = int(random_seed)

        self.w = None
        self._rng = np.random.default_rng(self.random_seed)

    def get_batch_by_indices(self, X, idx):
        if (isinstance(X, pd.DataFrame) or isinstance(X, pd.Series)):
            return X.iloc[idx]
        return X[idx]
    
    def fit(self, X, y, w_0=None, trace=False, X_val=None, y_val=None):
        N, D = X.shape

        if w_0 is None:
            w = np.zeros(D, dtype=float)
        else:
            w = w_0.copy().astype(float)

        history = None
        if trace:
            history = {'time': [], 'func': [], 'func_val': []}

        for k in range(1, self.max_iter + 1):
            start_time = time.time()
            w_prev = w.copy()

            eta_k = self.step_alpha / (k ** self.step_beta)

            if (self.batch_size is None or self.batch_size > N):
                grad = self.loss_function.grad(X, y, w)
                w = w - eta_k * grad
            else:
                perm = self._rng.permutation(N)
                for start in range(0, N, self.batch_size):
                    idx = perm[start: start + self.batch_size]
                    X_batch = self.get_batch_by_indices(X, idx)
                    y_batch = self.get_batch_by_indices(y, idx)
                    grad = self.loss_function.grad(X_batch, y_batch, w)
                    w = w - eta_k * grad

            epoch_time = time.time() - start_time

            if trace:
                history['time'].append(epoch_time)
                history['func'].append(self.loss_function.func(X, y, w))
                if (X_val is not None) and (y_val is not None):
                    history['func_val'].append(self.loss_function.func(X_val, y_val, w))
                else:
                    history['func_val'].append(None)

            if np.linalg.norm(w - w_prev) <= self.tolerance:
                self.w = w
                break

        self.w = w
        if trace:
            return history
        return

    def predict(self, X):
        if self.w.any():
            pred = X.dot(self.w)
            return np.asarray(pred).reshape(-1)
        raise ValueError("Сначала нужно вызвать fit")

    def get_weights(self):
        if self.w.any():
            return self.w
        return None

    def get_objective(self, X, y):
        if self.w.any():
            return float(self.loss_function.func(X, y, self.w))
        raise ValueError("Сначала нужно вызвать fit")